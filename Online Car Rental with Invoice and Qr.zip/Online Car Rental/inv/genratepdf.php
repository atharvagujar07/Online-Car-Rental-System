<?php 
session_start();
include('../includes/config.php');
error_reporting(0);
if(isset($_POST['submit']))
{
$fromdate=$_POST['fromdate'];
$todate=$_POST['todate']; 
$message=$_POST['message'];
$useremail=$_SESSION['login'];
$status=0;
$vhid=$_GET['vhid'];
$sql="INSERT INTO  tblbooking(userEmail,VehicleId,FromDate,ToDate,message,Status) VALUES(:useremail,:vhid,:fromdate,:todate,:message,:status)";
$query = $dbh->prepare($sql);
$query->bindParam(':useremail',$useremail,PDO::PARAM_STR);
$query->bindParam(':vhid',$vhid,PDO::PARAM_STR);
$query->bindParam(':fromdate',$fromdate,PDO::PARAM_STR);
$query->bindParam(':todate',$todate,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo "<script>alert('Booking successfull.');</script>";
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}

}

?>
<?php 
$vhid=intval($_GET['vhid']);
$sql = "SELECT tblvehicles.*,tblbrands.BrandName,tblbrands.id as bid  from tblvehicles join tblbrands on tblbrands.id=tblvehicles.VehiclesBrand where tblvehicles.id=:vhid";
$query = $dbh -> prepare($sql);
$query->bindParam(':vhid',$vhid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  
$_SESSION['brndid']=$result->bid;  
?>  
<?php }} ?>
<?php
function createpdf($brandname,$carname,$prize)
{
    require('./fpdf/fpdf.php');
    $pdf=new FPDF('p','mm','A4');
    $pdf->AddPage();
    $pdf->setFont('Arial','B','20');
    $pdf->Image('assets/logo.png',1,1);
    $pdf->cell(71,5,"",0.0);
    $pdf->cell(120,5,'Online Car Rental System Invoice',0,0);
    $pdf->cell(59,10,'',0,1);


    $pdf->setFont('Arial','B','15');
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'---------------------------------------------------------------------------------------------------------',0,0);
    $pdf->cell(50,20,"",0,1);
    $pdf->cell(130,5,'Invoice No:-',0,0);
    $pdf->cell(59,5,'OCRS123456789',0,0);

    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'Date:-',0,0);
    $pdf->cell(59,5,date("d-m-y"),0,0);

    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'Time:-',0,0);
    $pdf->cell(59,5,date("h:i:sa"),0,0);

    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'Customer Name:-',0,0);
    $pdf->cell(59,5,"Atharva Gujar",0,0);

    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'Address:-',0,0);
    $pdf->cell(59,5,'57/2,A-1,Kothrud Pune',0,0);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'       ',0,0);
    $pdf->cell(59,5,'Maharastra,411038',0,0);

    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'---------------------------------------------------------------------------------------------------------',0,0);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(50,10,"                                                   Billing Details",0,0,);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'---------------------------------------------------------------------------------------------------------',0,0);


    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,10,'Car name',0,0);
    $pdf->cell(59,5,'Prize',0,0);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'---------------------------------------------------------------------------------------------------------',0,0);

    $pdf->setFont('Arial','B','13');
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,10,$brandname,0,0);
    $pdf->cell(59,5,$prize,0,0);
    

    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,10,$carname,0,0);
    
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(50,10,"",0,1);
    



    $pdf->setFont('Arial','B','15');
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'---------------------------------------------------------------------------------------------------------',0,0);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,10,'Total Prize',0,0);
    $pdf->cell(59,5,$prize,0,0);
    $pdf->cell(50,10,"",0,1);
    $pdf->cell(130,5,'---------------------------------------------------------------------------------------------------------',0,0);


    $pdf->cell(50,10,"",0,1);
    $pdf->cell(50,5,"",0,1);
    $pdf->cell(130,10,'                                                                                            Signature',0,0);

    $pdf->Output();
}
createpdf($result->BrandName,$result->VehiclesTitle,$result->PricePerDay);

?>

