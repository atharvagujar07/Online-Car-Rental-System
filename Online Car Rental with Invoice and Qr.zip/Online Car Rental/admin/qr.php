<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_REQUEST['eid']))
	{
$eid=intval($_GET['eid']);
$status=1;
$sql = "UPDATE tblcontactusquery SET status=:status WHERE  id=:eid";
$query = $dbh->prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query-> bindParam(':eid',$eid, PDO::PARAM_STR);
$query -> execute();

$msg="Testimonial Successfully Inacrive";
}



 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Qr Code</title>
</head>
<body>
<script>
                        function generateUPICode() {
                            var vpa ='8805545888@paytm';
                            var pn  = 'Car Booking';
                            var tid = 1234567890;
                            var tr  = 'Success';
                            var tn  = 'Booking your dream cars' ;
                            var amt=<?php echo htmlentities($result->PricePerDay);?>;
            
          
                            var upiData="upi://pay?pa=8805545888@paytm&pn=Online%Car%Reantal%Shop&mc=0000&am="+amt+"&cu=INR&mode=02&purpose=MobileBill&orgid=159761";
                            var qrcode = new QRCode(document.getElementById("qrcode"), {
                text: upiData,
                width: 258,
                height: 258,
                
            });

            qrcode.make();
        }

    </script>
</body>
</html>