-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2023 at 06:34 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carrental`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2020-03-31 07:55:07');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `id` int(11) NOT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `VehicleId` int(11) DEFAULT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `userEmail`, `VehicleId`, `FromDate`, `ToDate`, `message`, `Status`, `PostingDate`) VALUES
(1, 'atharvagujar.789@gmail.com', 1, '2023-06-14', '2023-06-28', 'good', 1, '2023-06-02 09:42:43'),
(2, 'atharvagujar.789@gmail.com', 2, '2023-07-05', '2023-07-05', 'tyesss', 2, '2023-07-03 05:41:08'),
(3, 'atharvagujar.789@gmail.com', 2, '2023-07-05', '2023-08-02', 'gg', 1, '2023-07-03 06:03:18'),
(4, 'abc@gmail.com', 2, '2023-07-07', '2023-07-07', 'hii', 0, '2023-07-03 07:04:36');

-- --------------------------------------------------------

--
-- Table structure for table `tblbrands`
--

CREATE TABLE `tblbrands` (
  `id` int(11) NOT NULL,
  `BrandName` varchar(120) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbrands`
--

INSERT INTO `tblbrands` (`id`, `BrandName`, `CreationDate`, `UpdationDate`) VALUES
(1, 'BMW', '2023-04-18 14:05:50', NULL),
(2, 'Mahindra', '2023-07-02 09:42:41', NULL),
(3, 'Audi', '2023-07-02 09:42:49', NULL),
(4, 'Toyota', '2023-07-02 09:43:11', NULL),
(5, 'KIA', '2023-07-02 09:43:19', NULL),
(6, 'TATA', '2023-07-03 15:26:28', NULL),
(7, 'Land Rover', '2023-07-03 15:26:37', NULL),
(8, 'Audi', '2023-07-03 15:26:44', NULL),
(9, 'Mercedes', '2023-07-03 16:21:36', NULL),
(10, 'Lamborghini', '2023-07-03 16:26:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, '57/2,Kothrud Pune 411038', 'atharvagujar789@gmail.com', '8805545888');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusquery`
--

INSERT INTO `tblcontactusquery` (`id`, `name`, `EmailId`, `ContactNumber`, `Message`, `PostingDate`, `status`) VALUES
(1, 'amisha', 'abc@gmail.com', '98765433102', 'NA', '2023-04-29 06:52:43', NULL),
(2, 'Atharva Gujar', 'rawoolamisha@gmail.com', '8888888888', 'How to book car', '2023-07-03 05:53:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(1, 'Terms and Conditions', 'terms', ''),
(2, 'Privacy Policy', 'privacy', ''),
(3, 'About Us ', 'aboutus', '										Hello World Hiie&nbsp;'),
(4, 'FAQs', 'faqs', 'Hello World');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbltestimonial`
--

CREATE TABLE `tbltestimonial` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `Testimonial` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `EmailId`, `Password`, `ContactNo`, `dob`, `Address`, `City`, `Country`, `RegDate`, `UpdationDate`) VALUES
(1, 'Amisha', 'abc@gmail.com', '7927221283b1fb48f9e3a9092ad95ee7', '9876543210', NULL, NULL, NULL, NULL, '2023-04-29 06:51:19', NULL),
(2, 'Atharva Gujar', 'atharvagujar.789@gmail.com', 'c50fa65ffe483078cef74e944538d812', '885545888', NULL, NULL, NULL, NULL, '2023-06-02 07:23:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblvehicles`
--

CREATE TABLE `tblvehicles` (
  `id` int(11) NOT NULL,
  `VehiclesTitle` varchar(150) DEFAULT NULL,
  `VehiclesBrand` int(11) DEFAULT NULL,
  `VehiclesOverview` longtext DEFAULT NULL,
  `PricePerDay` float DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `Vimage1` varchar(120) DEFAULT NULL,
  `Vimage2` varchar(120) DEFAULT NULL,
  `Vimage3` varchar(120) DEFAULT NULL,
  `Vimage4` varchar(120) DEFAULT NULL,
  `Vimage5` varchar(120) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblvehicles`
--

INSERT INTO `tblvehicles` (`id`, `VehiclesTitle`, `VehiclesBrand`, `VehiclesOverview`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `Vimage1`, `Vimage2`, `Vimage3`, `Vimage4`, `Vimage5`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`) VALUES
(1, '5 series', 1, 'First class Ac', 9000, 'Petrol', 2022, 7, 'about_us_img1.jpg', 'banner-image-2.jpg', 'listing_img1.jpg', 'blog_img3.jpg', 'about_us_img4.jpg', 1, NULL, NULL, 1, 1, 1, 1, NULL, 1, 1, NULL, 1, '2023-04-18 14:08:38', NULL),
(2, 'Toyota  Fortuner Legend', 4, 'Full Luxury ,Car', 12000, 'Diesel', 2018, 7, 'fortunerlegenderfortunerlegenderrightfrontthreequarter.png', 'fortunerlegenderfortunerlegenderrightrearthreequarter.png', 'fortunerlegenderfortunerlegenderfrontrowseats.jpeg', 'fortunerlegenderfortunerlegenderrightfrontthreequarter.png', 'fortunerlegenderfortunerlegenderfrontrowseats.jpeg', 1, 1, 1, 1, NULL, 1, 1, 1, NULL, NULL, NULL, 1, '2023-07-02 09:46:35', NULL),
(3, ' Scorpio 2023 Edition', 2, 'stylish car at low budget', 7800, 'Petrol', 2023, 7, 'scorpioscorpiorightfrontthreequarter.jpeg', 'scorpioscorpioclassicrightfrontthreequarter.jpeg', 'scorpioscorpioclassicfrontrowseats.jpeg', 'scorpioscorpioclassicseatadjustmentmanualfordriver.jpeg', 'scorpioscorpioclassicrightfrontthreequarter.jpeg', 1, 1, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, NULL, '2023-07-02 09:49:02', NULL),
(4, 'Audi A9', 3, 'Luxury car sedan', 19000, 'Petrol', 2017, 5, 'a8la8lrightfrontthreequarter (1).jpeg', 'a8la8lrightfrontthreequarter (1).jpeg', 'a8la8ldashboard.jpeg', 'a8la8lfrontrowseats.jpeg', 'a8la8lfrontseatheadrest.jpeg', 1, 1, 1, 1, 1, 1, NULL, 1, 1, NULL, 1, NULL, '2023-07-03 15:29:21', NULL),
(5, 'Thar 2021', 2, 'Long Drive  Car', 13000, 'Diesel', 2021, 4, 'thartharrightfrontthreequarter.jpeg', 'thartharrightsideview.jpeg', 'thartharbootspacerearseatfolded.jpeg', 'tharmahindratharsteeringwheel.jpeg', 'thartharrearseats.jpeg', 1, 1, 1, NULL, 1, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 15:34:48', NULL),
(6, 'XUV300', 2, 'Car', 10000, 'Petrol', 2017, 5, 'xuv300turbosportxuv300sportzrightfrontthreequarter (1).jpeg', 'xuv300turbosportxuv300sportzrightfrontthreequarter.jpeg', 'xuv300turbosportxuv300turbosportrightfrontthreequarter.jpeg', 'xuv300turbosportxuv300sportzparkingbrakeemergencybrake.jpeg', 'xuv300turbosportxuv300sportzdashboard.jpeg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 15:37:15', NULL),
(7, 'Range Rover', 7, 'Luxury Car', 24000, 'Diesel', 2019, 7, 'rangeroverrangeroverrightfrontthreequarter.jpeg', 'rangeroverrangeroverdaytimerunninglampdrl.jpeg', 'rangeroverrangeroverfrontfoglamp.jpeg', 'rangerovernewrangeroverfrontrowseats.jpeg', 'rangeroverrangeroversteeringwheel.jpeg', 1, NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 15:39:17', NULL),
(8, 'Defender', 7, 'Feel The Luxury', 30000, 'Petrol', 2021, 7, 'defenderdefenderrightfrontthreequarter.jpeg', 'defenderexteriorrightfrontthreequarter.jpeg', 'defenderdefenderdaytimerunninglampdrl.jpeg', 'defenderdefenderdashboard.jpeg', 'defenderdefenderfrontrowseats.jpeg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 15:40:34', NULL),
(9, 'Safari', 6, 'Strong Car', 15000, 'Diesel', 2019, 7, 'safarisafarirightfrontthreequarter.jpeg', 'safarisafarirightsideview.jpeg', 'safaritatasafariinstrumentcluster0.jpeg', 'safaritatasafarithirdrowseats6 (1).jpeg', 'safarisafarirightsideview.jpeg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 15:42:15', NULL),
(10, 'Harrier', 6, 'Strong Car', 14000, 'Petrol', 2017, 5, 'harrierharrierrightfrontthreequarter.png', 'harrierharrierrearview.png', 'harrierharrierrightfrontthreequarter.jpeg', 'harriertataharrierdashboard20.jpeg', 'harriertataharrierfrontrowseats4.jpeg', 1, NULL, 1, 1, NULL, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 15:43:41', NULL),
(11, 'Benz  C-Class', 9, 'Feel THe Luxury', 25000, 'Diesel', 2020, 5, 'cclassnewcclassrightfrontthreequarter.jpeg', 'cclasscclassdaytimerunninglampdrl (1).jpeg', 'cclasscclassbootspacerearseatfolded.jpeg', 'cclasscclassdashboard.jpeg', 'cclasscclassrearseats (1).jpeg', 1, NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 16:24:56', NULL),
(12, 'Urus S Images ', 10, 'Super Car', 50000, 'Petrol', 2023, 4, 'urussurussrightfrontthreequarter (2).jpeg', 'urussurussrightfrontthreequarter.jpeg', 'urussurussrightfrontthreequarter (1).jpeg', 'urussurussfrontseatheadrest.jpeg', 'urussurussdashboard.jpeg', 1, NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-07-03 16:32:53', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbrands`
--
ALTER TABLE `tblbrands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblbrands`
--
ALTER TABLE `tblbrands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
